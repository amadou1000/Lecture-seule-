package com.lecture.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("lecture_settings", Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var speedLabel: TextView
    private lateinit var startButton: Button
    private lateinit var pauseButton: Button
    private lateinit var modeAllButton: Button
    private lateinit var modeReadingButton: Button
    private var speed = 2
    private var mode = "reading"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speed = prefs.getInt("speed", 2).coerceIn(1, 5)
        mode = prefs.getString("mode", "reading") ?: "reading"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(24), dp(22), dp(22))
            setBackgroundColor(0xFFF5F7F6.toInt())
        }

        root.addView(TextView(this).apply {
            text = "Lecture"
            textSize = 32f
            setTextColor(0xFF155D43.toInt())
            gravity = Gravity.CENTER
        }, matchWrap())

        root.addView(TextView(this).apply {
            text = "Le défilement automatique, simplement."
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFF4B5563.toInt())
            setPadding(0, dp(6), 0, dp(18))
        }, matchWrap())

        root.addView(TextView(this).apply {
            text = "Choisis ton mode"
            textSize = 18f
            setTextColor(0xFF26332D.toInt())
            setPadding(0, dp(6), 0, dp(8))
        }, matchWrap())

        modeAllButton = Button(this).apply {
            text = "Tout l’écran"
            contentDescription = "Mode Tout l’écran : défilement dans les applications compatibles"
        }
        root.addView(modeAllButton, buttonLayout())
        modeAllButton.setOnClickListener { setMode("all") }

        modeReadingButton = Button(this).apply {
            text = "Textes et livres"
            contentDescription = "Mode Lecture : défilement adapté aux textes et livres"
        }
        root.addView(modeReadingButton, buttonLayout())
        modeReadingButton.setOnClickListener { setMode("reading") }

        status = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFF26332D.toInt())
            setPadding(dp(8), dp(12), dp(8), dp(12))
        }
        root.addView(status, matchWrap())

        root.addView(TextView(this).apply {
            text = "Vitesse du défilement"
            textSize = 18f
            setTextColor(0xFF26332D.toInt())
            setPadding(0, dp(6), 0, dp(4))
        }, matchWrap())

        speedLabel = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFF155D43.toInt())
        }
        root.addView(speedLabel, matchWrap())

        val seek = SeekBar(this).apply {
            max = 4
            progress = speed - 1
            contentDescription = "Choisir la vitesse du défilement"
        }
        root.addView(seek, matchWrap())
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                speed = progress + 1
                prefs.edit().putInt("speed", speed).apply()
                updateSpeedLabel()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        startButton = Button(this).apply {
            textSize = 17f
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        root.addView(startButton, buttonLayout(60))
        startButton.setOnClickListener {
            if (!isAccessibilityEnabled()) {
                Toast.makeText(this, "Active le service Lecture dans les paramètres d’accessibilité.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                prefs.edit().putBoolean("running", true).putBoolean("paused", false).apply()
                updateStatus()
            }
        }

        pauseButton = Button(this).apply {
            textSize = 16f
            text = "Mettre en pause"
        }
        root.addView(pauseButton, buttonLayout())
        pauseButton.setOnClickListener {
            val running = prefs.getBoolean("running", false)
            if (running) {
                val paused = prefs.getBoolean("paused", false)
                prefs.edit().putBoolean("paused", !paused).apply()
                updateStatus()
            } else {
                Toast.makeText(this, "Démarre d’abord le défilement.", Toast.LENGTH_SHORT).show()
            }
        }

        val stopButton = Button(this).apply {
            text = "Arrêter"
            textSize = 16f
        }
        root.addView(stopButton, buttonLayout())
        stopButton.setOnClickListener {
            prefs.edit().putBoolean("running", false).putBoolean("paused", false).apply()
            updateStatus()
        }

        root.addView(TextView(this).apply {
            text = "Utilisation : active le service d’accessibilité, choisis un mode, puis démarre. Tu peux ensuite ouvrir l’application à faire défiler. Reviens ici pour mettre en pause ou arrêter."
            textSize = 13f
            setTextColor(0xFF59645E.toInt())
            setPadding(0, dp(12), 0, 0)
        }, matchWrap())

        setContentView(root)
        updateSpeedLabel()
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) updateStatus()
    }

    private fun setMode(newMode: String) {
        mode = newMode
        prefs.edit().putString("mode", mode).apply()
        updateStatus()
    }

    private fun updateSpeedLabel() {
        if (!::speedLabel.isInitialized) return
        val names = listOf("Très lente", "Lente", "Moyenne", "Rapide", "Très rapide")
        speedLabel.text = names[speed - 1]
    }

    private fun updateStatus() {
        if (!::status.isInitialized) return
        val enabled = isAccessibilityEnabled()
        val running = prefs.getBoolean("running", false)
        val paused = prefs.getBoolean("paused", false)
        status.text = when {
            !enabled -> "Étape 1 : active le service d’accessibilité."
            !running -> "Mode sélectionné : ${modeName()}. Prêt à démarrer."
            paused -> "Défilement en pause · Mode ${modeName()}."
            else -> "Défilement actif · Mode ${modeName()}."
        }
        startButton.text = if (running) "Redémarrer le défilement" else "Démarrer le défilement"
        pauseButton.text = if (paused) "Reprendre" else "Mettre en pause"
        modeAllButton.alpha = if (mode == "all") 1.0f else 0.75f
        modeReadingButton.alpha = if (mode == "reading") 1.0f else 0.75f
    }

    private fun modeName() = if (mode == "all") "Tout l’écran" else "Lecture"

    private fun isAccessibilityEnabled(): Boolean {
        val expected = "$packageName/${ScrollAccessibilityService::class.java.name}"
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
    private fun buttonLayout(height: Int = 52) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, dp(height)
    ).apply { topMargin = dp(4); bottomMargin = dp(4) }
}

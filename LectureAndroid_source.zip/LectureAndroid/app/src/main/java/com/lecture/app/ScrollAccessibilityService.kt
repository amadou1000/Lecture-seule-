package com.lecture.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class ScrollAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastGestureAt = 0L

    private val runner = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences("lecture_settings", MODE_PRIVATE)
            val running = prefs.getBoolean("running", false)
            val paused = prefs.getBoolean("paused", false)
            if (running && !paused) {
                val speed = prefs.getInt("speed", 2).coerceIn(1, 5)
                val mode = prefs.getString("mode", "reading") ?: "reading"
                val interval = when (speed) {
                    1 -> 2600L
                    2 -> 2000L
                    3 -> 1450L
                    4 -> 1050L
                    else -> 750L
                }
                if (System.currentTimeMillis() - lastGestureAt >= interval) {
                    performScrollGesture(mode)
                    lastGestureAt = System.currentTimeMillis()
                }
                handler.postDelayed(this, 150L)
            } else {
                handler.postDelayed(this, 250L)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.removeCallbacks(runner)
        handler.post(runner)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Le service ne lit pas et n’enregistre pas le contenu des pages.
    }

    override fun onInterrupt() {
        getSharedPreferences("lecture_settings", MODE_PRIVATE).edit()
            .putBoolean("running", false)
            .putBoolean("paused", false)
            .apply()
    }

    override fun onDestroy() {
        handler.removeCallbacks(runner)
        super.onDestroy()
    }

    private fun performScrollGesture(mode: String) {
        val metrics = resources.displayMetrics
        val x = metrics.widthPixels * 0.5f
        // Mode Lecture : balayage plus court et plus doux.
        // Mode Tout l’écran : balayage plus long pour faire défiler davantage.
        val startFraction = if (mode == "reading") 0.70f else 0.82f
        val endFraction = if (mode == "reading") 0.48f else 0.30f
        val startY = metrics.heightPixels * startFraction
        val endY = metrics.heightPixels * endFraction
        val path = Path().apply {
            moveTo(x, startY)
            lineTo(x, endY)
        }
        val duration = if (mode == "reading") 420L else 330L
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}

# Lecture — prototype Android

## Modes
- **Tout l’écran** : balayage plus long pour les applications compatibles.
- **Textes et livres** : balayage plus court et plus doux, adapté à la lecture.
- Cinq niveaux de vitesse.
- Démarrer, mettre en pause, reprendre et arrêter.
- Interface française, sans compte, sans publicité intégrée, sans permission Internet.

## Compiler
1. Installe Android Studio sur un ordinateur.
2. Ouvre le dossier `LectureAndroid` dans Android Studio.
3. Laisse Gradle synchroniser le projet.
4. Connecte un téléphone Android ou crée un émulateur.
5. Lance l’application avec **Run**. Pour créer un APK, utilise Build > Build APK(s).

## Première utilisation
1. Ouvre Lecture.
2. Appuie sur Démarrer : Android ouvre les paramètres d’accessibilité si le service n’est pas activé.
3. Active « Lecture – défilement automatique » et confirme l’avertissement système.
4. Reviens dans Lecture, choisis un mode et démarre.
5. Ouvre le texte ou l’application cible. Reviens dans Lecture pour mettre en pause ou arrêter.

## Limites
- Ce projet est le **code source**, pas un APK déjà compilé.
- Le service d’accessibilité est nécessaire pour simuler les gestes de balayage. Android affiche un avertissement système, ce qui est normal.
- Les modes modifient la longueur du geste, mais ne détectent pas automatiquement si une application affiche un livre ou un réseau social. Le défilement dépend de l’application cible et doit être testé sur le téléphone.
- Pour arrêter rapidement, reviens dans Lecture et appuie sur Arrêter, ou désactive le service dans les paramètres d’accessibilité.
